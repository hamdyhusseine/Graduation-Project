USE [GP]
GO

/****** Object:  Table [dbo].[Seller]    Script Date: 2/8/2020 5:43:58 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Seller](
	[sellerID] [int] NOT NULL,
	[name] [varchar](256) NOT NULL,
	[phone] [varchar](256) NOT NULL,
	[address] [varchar](256) NOT NULL,
	[socialLink] [varchar](256) NULL,
	[username] [varchar](256) NULL,
	[password] [varchar](256) NULL,
	[placeID] [int] NOT NULL,
 CONSTRAINT [PK_Seller] PRIMARY KEY CLUSTERED 
(
	[sellerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Seller]  WITH CHECK ADD  CONSTRAINT [FK_Seller_Place] FOREIGN KEY([placeID])
REFERENCES [dbo].[Place] ([placeID])
GO

ALTER TABLE [dbo].[Seller] CHECK CONSTRAINT [FK_Seller_Place]
GO


