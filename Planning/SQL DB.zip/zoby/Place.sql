USE [GP]
GO

/****** Object:  Table [dbo].[Place]    Script Date: 2/8/2020 5:43:43 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Place](
	[placeID] [int] NOT NULL,
	[title] [varchar](256) NOT NULL,
	[images] [int] NULL,
	[locationLat] [geography] NOT NULL,
	[locationLng] [geography] NOT NULL,
	[area] [varchar](256) NOT NULL,
	[isOpen] [int] NOT NULL,
	[currency] [varchar](256) NOT NULL,
	[amount] [varchar](256) NULL,
	[renters] [int] NOT NULL,
	[maximumResidents] [int] NOT NULL,
	[currentResidents] [varchar](256) NOT NULL,
	[description] [varchar](256) NOT NULL,
	[type] [varchar](256) NOT NULL,
 CONSTRAINT [PK_Place] PRIMARY KEY CLUSTERED 
(
	[placeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Place]  WITH CHECK ADD  CONSTRAINT [FK_Place_Customer] FOREIGN KEY([renters])
REFERENCES [dbo].[Customer] ([customerID])
GO

ALTER TABLE [dbo].[Place] CHECK CONSTRAINT [FK_Place_Customer]
GO

ALTER TABLE [dbo].[Place]  WITH CHECK ADD  CONSTRAINT [FK_Place_Images] FOREIGN KEY([images])
REFERENCES [dbo].[Images] ([imageID])
GO

ALTER TABLE [dbo].[Place] CHECK CONSTRAINT [FK_Place_Images]
GO


